export class ResponseResult {
    Messages: String[];
    Success: Boolean;
}