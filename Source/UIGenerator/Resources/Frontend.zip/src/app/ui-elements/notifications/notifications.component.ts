import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: '[ui-components]',
  templateUrl: './notifications.template.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./notifications.style.scss']
})
export class Notifications {
}

