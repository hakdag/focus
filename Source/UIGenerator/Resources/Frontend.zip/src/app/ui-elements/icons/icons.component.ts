import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: '[ui-tabs-accordion]',
  templateUrl: './icons.template.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./icons.style.scss']
})
export class Icons {
}

