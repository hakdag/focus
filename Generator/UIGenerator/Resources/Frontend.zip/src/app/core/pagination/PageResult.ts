export class PageResult {
    public Items: any;
    public AllItems: number;
    public CurrentPage: number;
    public PageCount: number;
}