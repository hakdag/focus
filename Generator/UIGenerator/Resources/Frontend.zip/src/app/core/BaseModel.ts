export class BaseModel {
	Id: number;
	CreatedDate: Date;
}